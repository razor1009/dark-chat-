const socket = io();

function send() {
    const name = document.getElementById("name").value || "anon";
    const msg = document.getElementById("msg").value;

    socket.emit("chat message", name + " : " + msg);
    document.getElementById("msg").value = "";
}

socket.on("chat message", function(msg) {
    const div = document.createElement("div");
    div.textContent = msg;
    document.getElementById("chat").appendChild(div);
});